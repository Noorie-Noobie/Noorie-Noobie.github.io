"""NutriAI planning package."""

